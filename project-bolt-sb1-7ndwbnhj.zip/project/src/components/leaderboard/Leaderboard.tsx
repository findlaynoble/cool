import React from 'react';
import { Trophy, Medal, Award, Target, TrendingUp } from 'lucide-react';

interface LeaderboardEntry {
  id: string;
  username: string;
  total_points: number;
  correct_predictions: number;
  total_predictions: number;
  current_streak: number;
  longest_streak: number;
}

interface LeaderboardProps {
  entries: LeaderboardEntry[];
  currentUserId?: string;
  loading?: boolean;
}

export function Leaderboard({ entries, currentUserId, loading = false }: LeaderboardProps) {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />;
      default:
        return (
          <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center">
            <span className="text-sm font-semibold text-gray-600">{rank}</span>
          </div>
        );
    }
  };

  const getAccuracy = (correct: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((correct / total) * 100);
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center gap-2 mb-6">
          <Trophy className="h-6 w-6 text-emerald-600" />
          <h2 className="text-xl font-bold text-gray-900">Leaderboard</h2>
        </div>
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="animate-pulse">
              <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="w-6 h-6 bg-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-24 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="h-6 bg-gray-200 rounded w-12"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-2">
          <Trophy className="h-6 w-6 text-emerald-600" />
          <h2 className="text-xl font-bold text-gray-900">Global Leaderboard</h2>
        </div>
        <p className="text-gray-600 mt-1">Top predictors this season</p>
      </div>

      <div className="p-6">
        {entries.length === 0 ? (
          <div className="text-center py-8">
            <Target className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No predictions yet!</p>
            <p className="text-sm text-gray-400">Be the first to make predictions and climb the leaderboard.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {entries.map((entry, index) => {
              const rank = index + 1;
              const isCurrentUser = entry.id === currentUserId;
              const accuracy = getAccuracy(entry.correct_predictions, entry.total_predictions);

              return (
                <div
                  key={entry.id}
                  className={`flex items-center gap-4 p-4 rounded-lg transition-all ${
                    isCurrentUser
                      ? 'bg-emerald-50 border-2 border-emerald-200 shadow-sm'
                      : 'bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex-shrink-0">
                    {getRankIcon(rank)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className={`font-semibold truncate ${
                        isCurrentUser ? 'text-emerald-900' : 'text-gray-900'
                      }`}>
                        {entry.username}
                      </p>
                      {isCurrentUser && (
                        <span className="px-2 py-1 text-xs font-medium bg-emerald-100 text-emerald-800 rounded-full">
                          You
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-4 mt-1 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Target className="h-3 w-3" />
                        <span>{accuracy}% accuracy</span>
                      </div>
                      {entry.current_streak > 0 && (
                        <div className="flex items-center gap-1 text-orange-600">
                          <TrendingUp className="h-3 w-3" />
                          <span>{entry.current_streak} streak</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="font-bold text-lg text-emerald-600">
                      {entry.total_points}
                    </p>
                    <p className="text-xs text-gray-500">points</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}