import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Header } from '../layout/Header';
import { FixtureCard } from '../fixtures/FixtureCard';
import { Leaderboard } from '../leaderboard/Leaderboard';
import { Calendar, Target, Award, TrendingUp } from 'lucide-react';

interface Team {
  id: string;
  name: string;
  short_name: string;
  logo_url: string;
  primary_color: string;
}

interface Fixture {
  id: string;
  home_team: Team;
  away_team: Team;
  match_date: string;
  gameweek: number;
  home_score: number | null;
  away_score: number | null;
  status: 'upcoming' | 'live' | 'completed';
  winner_id: string | null;
}

interface Prediction {
  id: string;
  fixture_id: string;
  predicted_winner_id: string | null;
  points_earned: number;
  is_correct: boolean | null;
}

interface UserProfile {
  id: string;
  username: string;
  total_points: number;
  correct_predictions: number;
  total_predictions: number;
  current_streak: number;
  longest_streak: number;
}

export function Dashboard() {
  const [fixtures, setFixtures] = useState<Fixture[]>([]);
  const [predictions, setPredictions] = useState<Prediction[]>([]);
  const [leaderboard, setLeaderboard] = useState<UserProfile[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [predictionLoading, setPredictionLoading] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'fixtures' | 'leaderboard'>('fixtures');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      await Promise.all([
        loadFixtures(),
        loadPredictions(),
        loadUserProfile(),
        loadLeaderboard(),
      ]);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadFixtures = async () => {
    const { data, error } = await supabase
      .from('fixtures')
      .select(`
        *,
        home_team:teams!fixtures_home_team_id_fkey(*),
        away_team:teams!fixtures_away_team_id_fkey(*)
      `)
      .order('match_date', { ascending: true });

    if (error) throw error;
    setFixtures(data || []);
  };

  const loadPredictions = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from('predictions')
      .select('*')
      .eq('user_id', user.id);

    if (error) throw error;
    setPredictions(data || []);
  };

  const loadUserProfile = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    if (error) throw error;
    setUserProfile(data);
  };

  const loadLeaderboard = async () => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('total_points', { ascending: false })
      .limit(10);

    if (error) throw error;
    setLeaderboard(data || []);
  };

  const handlePrediction = async (fixtureId: string, winnerId: string | null) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setPredictionLoading(fixtureId);

    try {
      // Check if prediction already exists
      const existingPrediction = predictions.find(p => p.fixture_id === fixtureId);

      if (existingPrediction) {
        // Update existing prediction
        const { error } = await supabase
          .from('predictions')
          .update({
            predicted_winner_id: winnerId === 'draw' ? null : winnerId,
            updated_at: new Date().toISOString(),
          })
          .eq('id', existingPrediction.id);

        if (error) throw error;

        // Update local state
        setPredictions(prev => prev.map(p => 
          p.id === existingPrediction.id 
            ? { ...p, predicted_winner_id: winnerId === 'draw' ? null : winnerId }
            : p
        ));
      } else {
        // Create new prediction
        const { data, error } = await supabase
          .from('predictions')
          .insert({
            user_id: user.id,
            fixture_id: fixtureId,
            predicted_winner_id: winnerId === 'draw' ? null : winnerId,
          })
          .select()
          .single();

        if (error) throw error;

        // Update local state
        setPredictions(prev => [...prev, data]);
      }
    } catch (error) {
      console.error('Error making prediction:', error);
    } finally {
      setPredictionLoading(null);
    }
  };

  const upcomingFixtures = fixtures.filter(f => f.status === 'upcoming');
  const recentFixtures = fixtures.filter(f => f.status === 'completed').slice(-5);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white p-6 rounded-xl">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header userProfile={userProfile || undefined} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        {userProfile && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-100 rounded-lg">
                  <Target className="h-5 w-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{userProfile.total_points}</p>
                  <p className="text-sm text-gray-600">Total Points</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Award className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">
                    {userProfile.total_predictions > 0 
                      ? Math.round((userProfile.correct_predictions / userProfile.total_predictions) * 100)
                      : 0}%
                  </p>
                  <p className="text-sm text-gray-600">Accuracy</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 rounded-lg">
                  <TrendingUp className="h-5 w-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{userProfile.current_streak}</p>
                  <p className="text-sm text-gray-600">Current Streak</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Calendar className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-900">{userProfile.total_predictions}</p>
                  <p className="text-sm text-gray-600">Predictions Made</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 mb-8 bg-white p-1 rounded-lg shadow-sm border border-gray-200 w-fit">
          <button
            onClick={() => setActiveTab('fixtures')}
            className={`px-6 py-2 rounded-md font-medium transition-all ${
              activeTab === 'fixtures'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Fixtures
          </button>
          <button
            onClick={() => setActiveTab('leaderboard')}
            className={`px-6 py-2 rounded-md font-medium transition-all ${
              activeTab === 'leaderboard'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Leaderboard
          </button>
        </div>

        {activeTab === 'fixtures' ? (
          <div className="space-y-8">
            {/* Upcoming Fixtures */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Upcoming Fixtures</h2>
              {upcomingFixtures.length === 0 ? (
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
                  <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No upcoming fixtures available</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {upcomingFixtures.map((fixture) => {
                    const prediction = predictions.find(p => p.fixture_id === fixture.id);
                    return (
                      <FixtureCard
                        key={fixture.id}
                        fixture={fixture}
                        prediction={prediction}
                        onPredict={handlePrediction}
                        loading={predictionLoading === fixture.id}
                      />
                    );
                  })}
                </div>
              )}
            </div>

            {/* Recent Results */}
            {recentFixtures.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Recent Results</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {recentFixtures.map((fixture) => {
                    const prediction = predictions.find(p => p.fixture_id === fixture.id);
                    return (
                      <FixtureCard
                        key={fixture.id}
                        fixture={fixture}
                        prediction={prediction}
                        onPredict={handlePrediction}
                      />
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        ) : (
          <Leaderboard 
            entries={leaderboard} 
            currentUserId={userProfile?.id}
          />
        )}
      </div>
    </div>
  );
}