import React from 'react';
import { useAuth } from '../../hooks/useAuth';
import { Trophy, LogOut, User, Target, Award } from 'lucide-react';

interface HeaderProps {
  userProfile?: {
    username: string;
    total_points: number;
    current_streak: number;
  };
}

export function Header({ userProfile }: HeaderProps) {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 bg-emerald-100 rounded-full">
              <Trophy className="h-6 w-6 text-emerald-600" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">PL Predictor</h1>
              <p className="text-xs text-gray-500">Premier League Predictions</p>
            </div>
          </div>

          {userProfile && (
            <div className="flex items-center gap-6">
              <div className="hidden sm:flex items-center gap-4 text-sm">
                <div className="flex items-center gap-1 text-emerald-600">
                  <Target className="h-4 w-4" />
                  <span className="font-semibold">{userProfile.total_points}</span>
                  <span className="text-gray-500">pts</span>
                </div>
                <div className="flex items-center gap-1 text-orange-600">
                  <Award className="h-4 w-4" />
                  <span className="font-semibold">{userProfile.current_streak}</span>
                  <span className="text-gray-500">streak</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 text-gray-700">
                  <div className="flex items-center justify-center w-8 h-8 bg-gray-100 rounded-full">
                    <User className="h-4 w-4" />
                  </div>
                  <span className="font-medium hidden sm:block">{userProfile.username}</span>
                </div>
                
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-1 px-3 py-1.5 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  <span className="hidden sm:block">Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}