import React, { useState } from 'react';
import { Calendar, Clock, CheckCircle, XCircle } from 'lucide-react';

interface Team {
  id: string;
  name: string;
  short_name: string;
  logo_url: string;
  primary_color: string;
}

interface Fixture {
  id: string;
  home_team: Team;
  away_team: Team;
  match_date: string;
  gameweek: number;
  home_score: number | null;
  away_score: number | null;
  status: 'upcoming' | 'live' | 'completed';
  winner_id: string | null;
}

interface Prediction {
  id: string;
  predicted_winner_id: string | null;
  points_earned: number;
  is_correct: boolean | null;
}

interface FixtureCardProps {
  fixture: Fixture;
  prediction?: Prediction;
  onPredict: (fixtureId: string, winnerId: string | null) => void;
  loading?: boolean;
}

export function FixtureCard({ fixture, prediction, onPredict, loading = false }: FixtureCardProps) {
  const [selectedWinner, setSelectedWinner] = useState<string | null>(
    prediction?.predicted_winner_id || null
  );

  const matchDate = new Date(fixture.match_date);
  const isUpcoming = fixture.status === 'upcoming';
  const canPredict = isUpcoming && !prediction;
  const hasResult = fixture.status === 'completed';

  const handlePrediction = (winnerId: string | null) => {
    if (!canPredict && !prediction) return;
    
    setSelectedWinner(winnerId);
    onPredict(fixture.id, winnerId);
  };

  const getWinnerDisplay = () => {
    if (hasResult && fixture.home_score !== null && fixture.away_score !== null) {
      if (fixture.home_score > fixture.away_score) return fixture.home_team.id;
      if (fixture.away_score > fixture.home_score) return fixture.away_team.id;
      return 'draw';
    }
    return null;
  };

  const actualWinner = getWinnerDisplay();

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Calendar className="h-4 w-4" />
          <span>Gameweek {fixture.gameweek}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Clock className="h-4 w-4" />
          <span>{matchDate.toLocaleDateString()}</span>
          <span>{matchDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
      </div>

      {/* Teams */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3 flex-1">
          <img
            src={fixture.home_team.logo_url}
            alt={fixture.home_team.name}
            className="w-8 h-8 rounded-full"
          />
          <div>
            <p className="font-semibold text-gray-900">{fixture.home_team.short_name}</p>
            <p className="text-xs text-gray-500">{fixture.home_team.name}</p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-center">
          {hasResult ? (
            <div className="flex items-center gap-2 font-bold text-lg">
              <span className={fixture.home_score! > fixture.away_score! ? 'text-emerald-600' : 'text-gray-700'}>
                {fixture.home_score}
              </span>
              <span className="text-gray-400">-</span>
              <span className={fixture.away_score! > fixture.home_score! ? 'text-emerald-600' : 'text-gray-700'}>
                {fixture.away_score}
              </span>
            </div>
          ) : (
            <div className="text-gray-400 font-medium">vs</div>
          )}
        </div>

        <div className="flex items-center gap-3 flex-1 justify-end">
          <div className="text-right">
            <p className="font-semibold text-gray-900">{fixture.away_team.short_name}</p>
            <p className="text-xs text-gray-500">{fixture.away_team.name}</p>
          </div>
          <img
            src={fixture.away_team.logo_url}
            alt={fixture.away_team.name}
            className="w-8 h-8 rounded-full"
          />
        </div>
      </div>

      {/* Prediction Section */}
      <div className="space-y-3">
        {prediction && (
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2">
              {prediction.is_correct === true && <CheckCircle className="h-5 w-5 text-emerald-600" />}
              {prediction.is_correct === false && <XCircle className="h-5 w-5 text-red-500" />}
              <span className="text-sm font-medium">
                Your prediction: {
                  prediction.predicted_winner_id === fixture.home_team.id ? fixture.home_team.short_name :
                  prediction.predicted_winner_id === fixture.away_team.id ? fixture.away_team.short_name :
                  'Draw'
                }
              </span>
            </div>
            {hasResult && (
              <div className="flex items-center gap-1">
                <span className="text-sm font-semibold text-emerald-600">
                  +{prediction.points_earned} pts
                </span>
              </div>
            )}
          </div>
        )}

        {(canPredict || (prediction && isUpcoming)) && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700">Make your prediction:</p>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => handlePrediction(fixture.home_team.id)}
                disabled={loading}
                className={`p-3 rounded-lg text-sm font-medium transition-all ${
                  selectedWinner === fixture.home_team.id
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                {fixture.home_team.short_name}
              </button>
              <button
                onClick={() => handlePrediction('draw')}
                disabled={loading}
                className={`p-3 rounded-lg text-sm font-medium transition-all ${
                  selectedWinner === 'draw'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                Draw
              </button>
              <button
                onClick={() => handlePrediction(fixture.away_team.id)}
                disabled={loading}
                className={`p-3 rounded-lg text-sm font-medium transition-all ${
                  selectedWinner === fixture.away_team.id
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                {fixture.away_team.short_name}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}